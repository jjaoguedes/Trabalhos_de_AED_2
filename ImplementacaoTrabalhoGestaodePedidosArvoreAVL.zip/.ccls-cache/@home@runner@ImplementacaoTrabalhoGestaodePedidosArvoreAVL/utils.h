#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

int gerar_numero_aleatorio();

#endif